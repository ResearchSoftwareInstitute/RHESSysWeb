#!/bin/sh
zip -r RHESSys.zip RHESSys -x RHESSys/.DS_Store RHESSys/*/.DS_Store
