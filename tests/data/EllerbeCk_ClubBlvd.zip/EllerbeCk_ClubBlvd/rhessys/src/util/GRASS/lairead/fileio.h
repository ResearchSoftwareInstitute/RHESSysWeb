void header_help(int *maxr, int *maxc, char* fndem);
void pause();
