#!/bin/bash

#./searchLog.py -v --startDatetime="2013 04 12"
./searchLog.py -v 
